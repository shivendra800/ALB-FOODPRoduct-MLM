@extends('admin.layouts.master')
@section('title', 'Ecom-Login-Data')


@section('content')

    <div class="main-content">
        <div class="section__content section__content--p10">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                    <div class="card-header">
                                 <span style="color:#007bff">Ecom</span> Login-Data</div>
                            <div class="card-body">
                
                                <div class="card-title">
                          
                                </div>
                                <hr>
                                 
                                  ID:  <input type="text"   value="ALBFOODPRODUCTS416210" readonly class="form-control">
                                  Password  <input type="text"  " value="XJKXmpOIb8" readonly class="form-control"> 
                                    
                                        

                                    </div>
                                   
                                    
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    

                                        

    </div>
@endsection
